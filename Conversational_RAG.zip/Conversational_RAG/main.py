import gradio as gr
import sys
sys.path.append('/home/harshitha/Desktop/personal Projets/AI_Avatar_project/STT_SpeechToText/')
sys.path.append('/home/harshitha/Desktop/personal Projets/AI_Avatar_project/TRANSLATE/')
sys.path.append('/home/harshitha/Desktop/personal Projets/AI_Avatar_project/TTS_Text_To_Speech/')
import gradio as gr
from pydub import AudioSegment
from google.cloud import speech
from google.cloud import texttospeech_v1
from google.cloud import translate_v2 as translate
from TranslateKE import translate_kannada_to_english
from TranslateEK import translate_english_to_kannada
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_groq import ChatGroq
from langchain.chains import RetrievalQA
from langchain_core.prompts import ChatPromptTemplate
from tts import synthesize_and_save_audio
import os

os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = '/home/harshitha/Desktop/personal Projets/AI_Avatar_project/Conversational_RAG/rural-reach-414709-tts_kannada.json'
voice_params = texttospeech_v1.VoiceSelectionParams(
    name='kn-IN-Standard-D',
    language_code='kn-IN'
)


DB_FAISS_PATH = "../vector_store/FAISS"

embeddings = HuggingFaceEmbeddings(model_name="BAAI/bge-large-en-v1.5",model_kwargs={'device': 'cpu'})
vectordb = FAISS.load_local(DB_FAISS_PATH, embeddings,allow_dangerous_deserialization=True)

def load_llm():
    llm = ChatGroq(temperature=0.1, groq_api_key="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", model_name="llama3-70b-8192")
    return llm

def retrieval_qa_chain(query):
        prompt_template = """You are a therapist DHVANI. who cousels and take therapy sessions with human, YOU ARE EMPATHETIC. you should be calm, patient and not judgemental. You listen more than you talk, Your answers should be
        crisp and within 3-5 sentences, If the human asks you to be more elaborative, then you can be. Be calm, patient and a person with positive good vibe.remember, you show emapthy to DHVANI.

        Context: {context}
        Question: {question}

        Only return the helpful answer below and nothing else.
        Helpful answer:
        """
 
        prompt = ChatPromptTemplate.from_template(prompt_template)
        llm = load_llm()
        db = vectordb
        qa_chain = RetrievalQA.from_chain_type(llm=llm,
                                        chain_type='stuff',
                                        retriever=db.as_retriever(search_kwargs={'k': 4}),
                                        return_source_documents=True,
                                        chain_type_kwargs={'prompt': prompt},
                                        verbose=True
                                        )
        response = qa_chain(query)
        print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@",response)
        answer = response['result']
        return answer
    
query = "Who are you?"
print(retrieval_qa_chain(query))
    
    
def assistant_logic(audio_file_path):
    # Transcribe audio input
    transcribed_text = transcribe_audio(audio_file_path)
    print("####################################################################")
    print(transcribed_text)
    # Translate Kannada text to English
    kannada_text = transcribed_text[0]
    translated_text = translate_kannada_to_english(kannada_text)
    print("####################################################################")
    print(translated_text)
    # Get answer using question-answering chain
    answer = retrieval_qa_chain(translated_text)
    print("####################################################################")
    print(answer)
    # Translate answer back to Kannada
    translated_answer = translate_english_to_kannada(answer)
    print("####################################################################")
    print(translated_answer)
    # Synthesize answer into audio
    output_file = "output_audio.mp3"
    synthesize_and_save_audio(translated_answer, voice_params, output_file)
    return translated_answer, output_file

def transcribe_audio(audio_file_path):
    # Convert audio file to WAV format and 16,000 Hz sample rate if needed
    audio = None
    if audio_file_path.endswith(".mp3"):
        # Convert MP3 to WAV and adjust sample rate using pydub
        audio = AudioSegment.from_mp3(audio_file_path)
    elif audio_file_path.endswith(".wav"):
        # Load WAV file
        audio = AudioSegment.from_wav(audio_file_path)
    else:
        print("Unsupported audio file format.")
        return
    
    # Convert audio to 16,000 Hz sample rate
    audio = audio.set_frame_rate(16000).set_channels(1)
    
    # Save the converted audio as a temporary file
    temp_wav_file = "/tmp/temp_audio.wav"
    audio.export(temp_wav_file, format="wav")
    
    # Initialize the client
    client = speech.SpeechClient()

    # Read the WAV audio file
    with open(temp_wav_file, "rb") as audio_file:
        content = audio_file.read()

    # Configure the audio settings
    audio = speech.RecognitionAudio(content=content)

    # Configure the recognition settings
    config = speech.RecognitionConfig(
        encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
        sample_rate_hertz=16000,
        language_code="kn-IN",  # Kannada language code
    )

    # Perform the speech-to-text request
    response = client.recognize(config=config, audio=audio)

    # Process the response
    transcripts = []
    for result in response.results:
        alternative = result.alternatives[0]
        transcripts.append(alternative.transcript)
    return transcripts

image_path = 'background.jpeg' # Replace with your image file path

absolute_path = os.path.abspath(image_path)

iface = gr.Interface(
    fn=assistant_logic,
    inputs=gr.Audio(source="microphone", type="filepath", labels=None),
    outputs=["text", gr.Audio(type="filepath", labels=None)],
    title="DHWANI,Your Therapist!",
    description="Talk to the voice assistant and get responses in text and audio formats.",
    css=".gradio-container {background: url('file=background.jpeg');background-size: cover; display: flex; flex-direction: column; align-items: center;} .gradio-title { color: white; font-family: 'Arial', sans-serif; font-size: 36px; font-weight: bold; } .input-box, .output-box { width: 100%; } .output-box { margin-top: 20px; }"
)



if __name__ == "__main__":
    iface.launch(allowed_paths=[absolute_path])

