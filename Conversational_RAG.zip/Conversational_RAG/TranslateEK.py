from google.cloud import translate_v2 as translateek
import time

import os
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = "rural-reach-414709-translate.json"

def translate_english_to_kannada(english_text):
    # Initialize the Google Cloud Translate client
    translate_client = translateek.Client()

    # Define the source and target languages
    source_language = 'en'  # English language code
    target_language = 'kn'  # Kannada language code

    # Retry logic with exception handling
    max_retries = 3
    for attempt in range(max_retries):
        try:
            # Translate the text from English to Kannada
            translation = translate_client.translate(
                english_text,
                source_language=source_language,
                target_language=target_language
            )
            # Return the translated text if successful
            return translation['translatedText']
        
        except Exception as e:
            print(f"Attempt {attempt + 1} failed: {e}")
            # If the request fails, wait for a short period before retrying
            if attempt < max_retries - 1:
                time.sleep(2)
            else:
                return "Failed to translate text after multiple attempts."

"""
# Example usage
if __name__ == "__main__":
    english_text = "Hello, how are you?"  # Sample English sentence
    kannada_translation = translate_english_to_kannada(english_text)
    print(f"English: {english_text}")
    print(f"Kannada: {kannada_translation}")
    """
