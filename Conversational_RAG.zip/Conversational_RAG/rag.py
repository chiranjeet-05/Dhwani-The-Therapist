from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_groq import ChatGroq
from langchain.chains import RetrievalQA
from langchain_core.prompts import ChatPromptTemplate


DB_FAISS_PATH = "../vector_store/FAISS"

embeddings = HuggingFaceEmbeddings(model_name="BAAI/bge-large-en-v1.5",model_kwargs={'device': 'cpu'})
vectordb = FAISS.load_local(DB_FAISS_PATH, embeddings,allow_dangerous_deserialization=True)

def load_llm():
    llm = ChatGroq(temperature=0.1, groq_api_key="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", model_name="llama3-70b-8192")
    return llm

def retrieval_qa_chain(query):
        prompt_template = """You are a therapist DHWANI. who cousels and take therapy sessions with human, YOU ARE EMPATHETIC. you should be calm, patient and not judgemental. You listen more than you talk, Your answers should be
        crisp and within 3-5 sentences, If the human asks you to be more elaborative, then you can be. Be calm, patient and a person with positive good vibe.remember, you show emapthy to people.

        Context: {context}
        Question: {question}

        Only return the helpful answer below and nothing else.
        Helpful answer:
        """
 
        prompt = ChatPromptTemplate.from_template(prompt_template)
        llm = load_llm()
        db = vectordb
        qa_chain = RetrievalQA.from_chain_type(llm=llm,
                                        chain_type='stuff',
                                        retriever=db.as_retriever(search_kwargs={'k': 4}),
                                        return_source_documents=True,
                                        chain_type_kwargs={'prompt': prompt},
                                        verbose=True
                                        )
        response = qa_chain(query)
        print("#################################",response)
        answer = response['result']
        return answer
    
query = "Who are you?"
print(retrieval_qa_chain(query))
    


