import os
from google.cloud import texttospeech_v1
import io
from pydub import AudioSegment

os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'rural-reach-414709-tts_kannada.json'
client = texttospeech_v1.TextToSpeechClient()

# Define a function to synthesize speech
def synthesize_text(text, voice_params):
    synthesis_input = texttospeech_v1.SynthesisInput(text=text)
    response = client.synthesize_speech(
        input=synthesis_input,
        voice=voice_params,
        audio_config=texttospeech_v1.AudioConfig(
            audio_encoding=texttospeech_v1.AudioEncoding.LINEAR16
        )
    )
    return response.audio_content

# Load the desired voice
voice_params = texttospeech_v1.VoiceSelectionParams(
    name='kn-IN-Standard-A',
    language_code='kn-IN',
    ssml_gender=texttospeech_v1.SsmlVoiceGender.FEMALE 
)

# Define a function to convert linear16 audio to mp3
def convert_to_mp3(wav_file, mp3_file):
    sound = AudioSegment.from_wav(wav_file)
    sound.export(mp3_file, format="mp3")
    
#Speech to text     

def synthesize_and_save_audio(text, voice_params, output_file):
	# Load the desired voice
    
    audio_content = synthesize_text(text, voice_params)
    # Save audio as wav file
    wav_file = output_file[:-4] + ".wav"
    try:
        with open(wav_file, "wb") as f:
            f.write(audio_content)
        # Convert wav to mp3
        convert_to_mp3(wav_file, output_file)
        # Clean up temporary wav file
        os.remove(wav_file)
        print(f"Audio file saved successfully: {output_file}")
    except Exception as e:
        print(f"Error saving audio file: {e}")

"""
# Example usage:
text = "ದಸರಾ, ಅಥವಾ ವಿಜಯದಶಮಿ, ಕನ್ನಡ ನಾಡಿನ ಅತ್ಯಂತ ವಿಜೃಂಬಣೆಯ ಹಬ್ಬಗಳಲ್ಲಿ ಒಂದು."
output_file = "output_audio.mp3"
synthesize_and_save_audio(text, voice_params, output_file)
"""
