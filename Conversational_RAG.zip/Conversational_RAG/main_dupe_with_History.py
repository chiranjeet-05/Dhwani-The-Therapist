import gradio as gr
from pydub import AudioSegment
from google.cloud import speech
from google.cloud import texttospeech_v1
from google.cloud import translate_v2 as translate
from TranslateKE import translate_kannada_to_english
from TranslateEK import translate_english_to_kannada
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_groq import ChatGroq
from langchain.chains import RetrievalQA
from langchain_core.prompts import ChatPromptTemplate
from tts import synthesize_and_save_audio
from langchain.schema.runnable import RunnablePassthrough
from langchain.schema.output_parser import StrOutputParser
from langchain.chains import create_history_aware_retriever
from langchain_core.prompts import MessagesPlaceholder
from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_core.runnables import Runnable
import logging
import os

os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = '/home/harshitha/Desktop/personal Projets/AI_Avatar_project/Conversational_RAG/rural-reach-414709-tts_kannada.json'
voice_params = texttospeech_v1.VoiceSelectionParams(
    name='kn-IN-Standard-A',
    language_code='kn-IN'
)

DB_FAISS_PATH = "../vector_store/FAISS"

embeddings = HuggingFaceEmbeddings(model_name="BAAI/bge-large-en-v1.5", model_kwargs={'device': 'cpu'})
vectordb = FAISS.load_local(DB_FAISS_PATH, embeddings, allow_dangerous_deserialization=True)

def load_llm():
    llm = ChatGroq(temperature=0.1, groq_api_key="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", model_name="llama3-70b-8192")
    return llm

def retrieval_qa_chain(input, session_id="abc123"):
    llm = load_llm()
    db = vectordb
    retriever = vectordb.as_retriever(search_kwargs={'k': 4})

    contextualize_q_system_prompt = (
        "Given a chat history and the latest user question "
        "which might reference context in the chat history, "
        "formulate a standalone question which can be understood "
        "without the chat history. Do NOT answer the question, "
        "just reformulate it if needed and otherwise return it as is."
    )
    contextualize_q_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", contextualize_q_system_prompt),
            MessagesPlaceholder("chat_history"),
            ("human", "{input}"),
        ]
    )
    history_aware_retriever = create_history_aware_retriever(
        llm, retriever, contextualize_q_prompt
    )

    system_prompt = (
        """You are a therapist DHVANI. who counsels and takes therapy sessions with humans. YOU ARE EMPATHETIC. You should be calm, patient, and not judgemental. You listen more than you talk. Your answers should be
        crisp and within 3-5 sentences. If the human asks you to be more elaborate, then you can be. Be calm, patient, and a person with a positive good vibe. Remember, you show empathy to DHVANI.
        if you think the person is too depressed , then you will have to suggest him to go to a real therapist altogether.
        """
        "{context}"
    )
    qa_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", system_prompt),
            MessagesPlaceholder("chat_history"),
            ("human", "{input}"),
        ]
    )
    question_answer_chain = create_stuff_documents_chain(llm, qa_prompt)

    rag_chain = create_retrieval_chain(history_aware_retriever, question_answer_chain)

    store = {}

    def get_session_history(session_id: str) -> BaseChatMessageHistory:
        if session_id not in store:
            store[session_id] = ChatMessageHistory()
        return store[session_id]

    conversational_rag_chain = RunnableWithMessageHistory(
        rag_chain,
        get_session_history,
        input_messages_key="input",
        history_messages_key="chat_history",
        output_messages_key="answer",
    )
    logging.getLogger().setLevel(logging.ERROR)

    response = conversational_rag_chain.invoke(
        {"input": input},
        config={
            "configurable": {"session_id": session_id}
        }
    )["answer"]
    return response

def assistant_logic(audio_file_path, chat_history):
    # Transcribe audio input
    transcribed_text = transcribe_audio(audio_file_path)
    # Translate Kannada text to English
    kannada_text = transcribed_text[0]
    translated_text = translate_kannada_to_english(kannada_text)
    # Get answer using question-answering chain
    answer = retrieval_qa_chain(translated_text, session_id="abc123")
    # Translate answer back to Kannada
    translated_answer = translate_english_to_kannada(answer)
    # Synthesize answer into audio
    output_file = "output_audio.mp3"
    synthesize_and_save_audio(translated_answer, voice_params, output_file)

    # Update chat history
    chat_history.append((kannada_text, translated_answer))
    return chat_history, output_file, chat_history

def transcribe_audio(audio_file_path):
    # Convert audio file to WAV format and 16,000 Hz sample rate if needed
    audio = None
    if audio_file_path.endswith(".mp3"):
        audio = AudioSegment.from_mp3(audio_file_path)
    elif audio_file_path.endswith(".wav"):
        audio = AudioSegment.from_wav(audio_file_path)
    else:
        print("Unsupported audio file format.")
        return

    audio = audio.set_frame_rate(16000).set_channels(1)
    temp_wav_file = "/tmp/temp_audio.wav"
    audio.export(temp_wav_file, format="wav")

    client = speech.SpeechClient()

    with open(temp_wav_file, "rb") as audio_file:
        content = audio_file.read()

    audio = speech.RecognitionAudio(content=content)

    config = speech.RecognitionConfig(
        encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
        sample_rate_hertz=16000,
        language_code="kn-IN",
    )

    response = client.recognize(config=config, audio=audio)

    transcripts = []
    for result in response.results:
        alternative = result.alternatives[0]
        transcripts.append(alternative.transcript)
    return transcripts

image_path = 'gr_back.jpeg'
absolute_path = os.path.abspath(image_path)

iface = gr.Interface(
    fn=assistant_logic,
    inputs=[gr.Audio(source="microphone", type="filepath"), gr.State([])],
    outputs=[gr.Chatbot(), gr.Audio(type="filepath"), gr.State()],
    title="DHWANI, Your Therapist!",
    description="Talk to the voice assistant and get responses in text and audio formats.",
    css=".gradio-container {background: url('file=gr_back.jpeg'); background-size: cover; display: flex; flex-direction: column; align-items: center;} .gradio-title { color: white; font-family: 'Arial', sans-serif; font-size: 36px; font-weight: bold; } .input-box, .output-box { width: 100%; } .output-box { margin-top: 20px; }"
)

if __name__ == "__main__":
    iface.launch(allowed_paths=[absolute_path])
